create table Naukri_172477
(
FullName varchar(50),
EmailId varchar(50) primary key,
MobileNumber char(10),
DOB date,
Gender char(10),
Skills varchar(30),
State varchar(20),
City varchar(30)
)
select * from Naukri_172477

create proc usp_Add_naukri
(
@FullName varchar(50),
@EmailId varchar(50),
@MobileNumber char(10),
@DOB date,
@Gender char(10),
@Skills varchar(30),
@State varchar(20),
@City varchar(30)
)
as
begin
insert into Naukri_172477 values(@FullName,@EmailId,@MobileNumber,@DOB,@Gender,@Skills,@State,@City)
end
create proc usp_display_naukri
as
begin
select * from Naukri_172477
end
select Skills from  Naukri_172477

delete from Naukri_172477


create proc usp_search_naukri11
(
@EmailId varchar(20)
)
as
begin
select * from Naukri_172477 where EmailId=@EmailId
end

create proc usp_update_naukri
(
@FullName varchar(50),
@EmailId varchar(50),
@MobileNumber varchar(50)
)
as
begin
update Naukri_172477 set FullName=@FullName,EmailId=@EmailId,MobileNumber=@MobileNumber where EmailId=@EmailId
end
delete from Naukri_172477
create proc usp_delete_naukri
(
@EmailId varchar(40)
)
as
begin
delete Naukri_172477 where EmailId=@EmailId
end

create proc usp_count_naukri
as
begin
select count(*) from Naukri_172477
end