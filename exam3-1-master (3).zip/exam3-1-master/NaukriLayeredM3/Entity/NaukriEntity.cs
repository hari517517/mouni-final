﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class NaukriEntity
    {
        public string FullName { get; set; }
        public string EmailId { get; set; }
        public string MobileNumber { get; set; }
        public DateTime DOB { get; set; }
        public string Gender { get; set; }
        public string Skills { get; set; }
        public string State { get; set; }
        public string City { get; set; }
    }
}
