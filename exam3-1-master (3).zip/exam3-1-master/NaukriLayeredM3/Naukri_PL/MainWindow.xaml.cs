﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Exception1;
using Entity;
using BAL;
using System.Windows.Controls.Primitives;
using System.Data.SqlClient;

using System.Data.SqlClient;using DAL;

namespace Naukri_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public  void Show()
        {
            try
            {
                List<NaukriEntity> naukriList =NaukriBAL.RetrieveStudent();

                if (naukriList == null || naukriList.Count <= 0)
                    throw new NaukriException("Records not available");
                else
                {
                    dgnaukri.DataContext = naukriList;
                }
            }
            catch (NaukriException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void clear()
        {
            txtname.Text= null;
            txtmail.Text = null;
            txtmobile.Text = null;
            dpdate.Text = null;
           
            rbfemale.IsChecked = false;
            rbmale.IsChecked = false;

            cbjava.IsChecked = false;
            cbcsharp.IsChecked = false;
            cbcplus.IsChecked = false;
            cmbState.IsEditable = false;
            cmbcity.IsReadOnly=false;
        }

        private void Btnsearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string emailid = txtmail.Text;

                NaukriEntity naukriEntity = NaukriBAL.SearchStudent(emailid);

                if (naukriEntity != null)
                {

                    txtname.Text = naukriEntity.FullName.ToString();
                    txtmail.Text = naukriEntity.EmailId.ToString();
                    txtmobile.Text = naukriEntity.MobileNumber.ToString();
                    if(naukriEntity.Gender=="Male")
                    {
                        rbmale.IsChecked = true;
                    }
                    else if(naukriEntity.Gender=="Female")
                    {
                        rbfemale.IsChecked = true;
                    }
                    naukriEntity.Gender.ToString();

                    //rbmale = Convert.ToBoolean(gendercmnd);
                    //if ( == true)
                    //    Convert.ToBoolean(rbmale.Checked);
                    //else
                    //    Convert.ToBoolean(radioButton2.Checked);
                    //rbmale.IsChecked = true;
                    //rbfemale.IsChecked = true;
                    //txtStudCode.Text = stud.Scode.ToString();
                    //txtStudName.Text = stud.SName;
                    //txtDeptCode.Text = stud.DCode.ToString();
                    //txtDob.Text = stud.Dob.ToString();
                    //txtAddress.Text = stud.Address;

                    //update.IsEnabled = true;
                    //del.IsEnabled = true;
                    //txtStudCode.IsReadOnly = true;
                    //txtStudName.IsReadOnly = true;
                    //txtDob.IsEnabled = false;

                    btndelete.IsEnabled = true;

                }
                else
                    throw new NaukriException("Student record not found");
            }
            
            catch (NaukriException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Btnsave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                
                NaukriEntity naukriEntity = new NaukriEntity();
                naukriEntity.FullName = txtname.Text;
                naukriEntity.EmailId = txtmail.Text;
                naukriEntity.MobileNumber = txtmobile.Text;
                naukriEntity.DOB = Convert.ToDateTime(dpdate.Text);
                string gender = "";
                if (rbmale.IsChecked == true)
                {
                    gender = "male";
                }
                else if (rbfemale.IsChecked == true)
                {
                    gender = "female";
                }
                naukriEntity.Gender = gender;

                string skills = "";
                //foreach (var item in naukriEntity.Skills)
                //{
                //    cbjava.IsChecked = true;
                //    skills = "java";
                //    cbcsharp.IsChecked = true;
                //    skills = skills + "and" + "c#";
                //}
                if (cbjava.IsChecked == true)
                {
                    skills = "java";
                }
                if (cbcsharp.IsChecked == true)
                {
                    skills = skills + "," + "c# ";
                }
                if (cbcplus.IsChecked == true)
                {
                    skills = skills + "," + "C++";
                }
                naukriEntity.Skills = skills;
                btndelete.IsEnabled = false;

                naukriEntity.State = ((ComboBoxItem)cmbState.SelectedItem).Content.ToString();
                naukriEntity.City = ((ComboBoxItem)cmbcity.SelectedItem).Content.ToString();
                int recordaffected = NaukriBAL.InsertStudent(naukriEntity);
                if (recordaffected >= 1)
                {
                    MessageBox.Show("record successfully inserted into the table check onces the record in the grid");
                    clear();
                    Show();
                }
                else
                {
                    MessageBox.Show("record is not inserted check your code ");
                }
               
               
               
            }
            catch (NaukriException ex)
            {

                MessageBox.Show(ex.Message);
            }
            catch(SystemException ex)
            {
                throw ex;
            }

        }

        private void Btnupdate_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                NaukriEntity naukriEntity = new NaukriEntity();

                naukriEntity.FullName = txtname.Text;
                naukriEntity.EmailId = txtmail.Text;
                naukriEntity.MobileNumber = txtmobile.Text;

                int recordsAffected = NaukriBAL.UpdateStudent(naukriEntity);

                if (recordsAffected >=1)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    clear();
                }
                else
                    throw new NaukriException("Record not updated");
            }
            catch (NaukriException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btndelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string emailid = txtmail.Text;

                int recordsAffected = NaukriBAL.DeleteStudent(emailid);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    clear();
                }
                else
                    throw new NaukriException("Record not deleted");
            }
            catch (NaukriException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Btncount_Click(object sender, RoutedEventArgs e)
        {

            SqlCommand cmd = DataConnection.GenerateCommand();
            cmd.CommandText = "usp_count_naukri";


            cmd.Connection.Open();
            int count = (int)cmd.ExecuteScalar();
            cmd.Connection.Close();


            MessageBox.Show("Number of students are: " + count);
        }

        private void Btnclear_Click(object sender, RoutedEventArgs e)
        {
            clear();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

      

       
    }
}
